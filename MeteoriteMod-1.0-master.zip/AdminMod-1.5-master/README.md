# ExampleMod
An example of a simple mod for Mindustry.

## Importing

Simply download this repository as a zip, then import it through the `Mods` dialog in Mindustry. Or, unzip this repo inside Mindustry's `mods/` folder.

## Contributing

Created by Vaox

Social Links
https://discord.gg/jbtsQqM
youtube.com/c/vaox_animates
